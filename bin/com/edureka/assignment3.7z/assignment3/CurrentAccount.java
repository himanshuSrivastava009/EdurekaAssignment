package com.edureka.assignment3;

public final class CurrentAccount extends Bank {

	public void deposit(double amount)
	{
		super.deposit(amount);
	}
	
	public void withdraw(double amount)
	{
		super.withdraw(amount);
	}
	
}
